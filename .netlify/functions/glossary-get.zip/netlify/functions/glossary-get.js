var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/glossary-get.js
var glossary_get_exports = {};
__export(glossary_get_exports, {
  handler: () => handler
});
module.exports = __toCommonJS(glossary_get_exports);
var import_promises = __toESM(require("fs/promises"));
var import_path = __toESM(require("path"));
var GLOSSARY_PATH = import_path.default.join(process.cwd(), "data", "glossary-data.json");
async function handler() {
  try {
    const content = await import_promises.default.readFile(GLOSSARY_PATH, "utf-8");
    const glossary = JSON.parse(content);
    const flat = [];
    for (const category in glossary) {
      for (const term in glossary[category]) {
        flat.push({
          category,
          term,
          definition: glossary[category][term]
        });
      }
    }
    flat.sort((a, b) => {
      if (a.category !== b.category) return a.category.localeCompare(b.category);
      return a.term.localeCompare(b.term);
    });
    return {
      statusCode: 200,
      body: JSON.stringify(flat)
    };
  } catch (error) {
    console.error("Error loading glossary:", error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: "Failed to load glossary." })
    };
  }
}
// Annotate the CommonJS export names for ESM import in node:
0 && (module.exports = {
  handler
});
