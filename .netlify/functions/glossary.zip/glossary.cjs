var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));
var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

// netlify/functions/glossary.js
var glossary_exports = {};
__export(glossary_exports, {
  default: () => handler
});
module.exports = __toCommonJS(glossary_exports);
var import_promises = __toESM(require("fs/promises"));
var import_path = __toESM(require("path"));
var GLOSSARY_PATH = import_path.default.join(process.cwd(), "data", "glossary-data.json");
var SECRET = process.env.ADMIN_SECRET;
var send = (code, data) => ({
  statusCode: code,
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(data)
});
async function handler(event) {
  const token = event.headers["x-admin-token"];
  if (token !== SECRET) return send(401, { error: "Unauthorized" });
  try {
    const fileContent = await import_promises.default.readFile(GLOSSARY_PATH, "utf-8");
    const glossary = JSON.parse(fileContent);
    switch (event.httpMethod) {
      case "GET":
        return send(200, glossary);
      case "POST": {
        const { category, term, definition } = JSON.parse(event.body || "{}");
        if (!category || !term || !definition)
          return send(400, { error: "Missing fields" });
        if (!glossary[category]) glossary[category] = {};
        glossary[category][term] = definition;
        await import_promises.default.writeFile(GLOSSARY_PATH, JSON.stringify(glossary, null, 2));
        return send(201, { success: true });
      }
      case "PUT": {
        const { category, term, definition } = JSON.parse(event.body || "{}");
        if (!category || !term || !definition)
          return send(400, { error: "Missing fields" });
        if (!glossary[category] || !glossary[category][term])
          return send(404, { error: "Term not found" });
        glossary[category][term] = definition;
        await import_promises.default.writeFile(GLOSSARY_PATH, JSON.stringify(glossary, null, 2));
        return send(200, { success: true });
      }
      case "DELETE": {
        const { category, term } = JSON.parse(event.body || "{}");
        if (!category || !term) return send(400, { error: "Missing fields" });
        if (!glossary[category] || !glossary[category][term])
          return send(404, { error: "Term not found" });
        delete glossary[category][term];
        if (Object.keys(glossary[category]).length === 0) {
          delete glossary[category];
        }
        await import_promises.default.writeFile(GLOSSARY_PATH, JSON.stringify(glossary, null, 2));
        return send(204, {});
      }
      default:
        return send(405, { error: "Method not allowed" });
    }
  } catch (error) {
    return send(500, { error: "Internal Server Error", details: error.message });
  }
}
